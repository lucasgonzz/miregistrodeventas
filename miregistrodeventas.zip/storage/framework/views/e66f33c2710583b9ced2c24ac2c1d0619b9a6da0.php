<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <meta name="user" content="<?php echo e(Auth()->user()); ?>">
    <meta name="asset" content="<?php echo e(asset('')); ?>">
    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">

    <!-- Styles -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">

    <!-- Icons -->
    <link href="<?php echo e(asset('styles.css')); ?>" rel="stylesheet">
    <!-- sad -->
</head>
<body>
    <!-- <div id="app"> -->
        <?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <main class="py-4">
            <div id="app">
                <?php echo $__env->yieldContent('content'); ?>
            </div>
        </main>
    <!-- </div> -->
<script src="<?php echo e(asset('js/app.js')); ?>"></script>
<?php echo $__env->yieldContent('scripts'); ?>
</body>
</html>
<?php /**PATH C:\wamp64\www\miregistrodeventas\resources\views/layouts/app.blade.php ENDPATH**/ ?>