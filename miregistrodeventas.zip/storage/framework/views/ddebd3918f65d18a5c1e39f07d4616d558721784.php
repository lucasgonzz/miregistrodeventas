<?php $__env->startSection('content'); ?>
<ventas rol="commerce"></ventas>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\miregistrodeventas\resources\views/commerce/main/ventas.blade.php ENDPATH**/ ?>