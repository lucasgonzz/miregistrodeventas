<?php $__env->startSection('content'); ?>
<div class="row">
	<div class="col">
		<div class="card">
			<div class="card-header">
				Configuración
			</div>
			<div class="card-body">
				<div class="card">
					<div class="card-header">
						Artículos
					</div>
					<div class="card-body">
						<form action="">
							<div class="form-group">
								<label for=""></label>
							</div>
						</form>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\miregistrodeventas\resources\views/commerce/main/config.blade.php ENDPATH**/ ?>