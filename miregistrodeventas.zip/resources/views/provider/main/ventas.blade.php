@extends('layouts.app')

@section('content')
<ventas rol="provider"></ventas>
@endsection