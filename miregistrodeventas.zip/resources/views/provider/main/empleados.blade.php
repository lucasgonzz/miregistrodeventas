@extends('layouts.app')

@section('content')
<empleados rol="provider"></empleados>
@endsection