@extends('layouts.app')
@section('content')
<vender-provider></vender-provider>
@endsection

