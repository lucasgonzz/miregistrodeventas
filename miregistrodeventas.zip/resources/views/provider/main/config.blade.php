@extends('layouts.app')
@section('content')
<configuracion rol="provider"></configuracion>
@endsection