@extends('layouts.app')

@section('content')
<!-- {{ Auth()->user()->hasRole('commerce') }} -->
<ingresar rol="provider"></ingresar>
@endsection

