@extends('layouts.app')
@section('content')
<div class="row">
	<div class="col">
		<div class="card">
			<div class="card-header">
				Configuración
			</div>
			<div class="card-body">
				<div class="card">
					<div class="card-header">
						Artículos
					</div>
					<div class="card-body">
						<form action="">
							<div class="form-group">
								<label for=""></label>
							</div>
						</form>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
@endsection