@extends('layouts.app')

@section('content')
<ventas rol="commerce"></ventas>
@endsection