@extends('layouts.app')

@section('content')
<ventas></ventas>
@endsection