@extends('layouts.app')

@section('content')
<empleados rol="commerce"></empleados>
@endsection