@extends('layouts.app')

@section('content')
<ingresar rol="commerce"></ingresar>
@endsection