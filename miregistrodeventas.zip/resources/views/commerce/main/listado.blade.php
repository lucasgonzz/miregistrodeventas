@extends('layouts.app')

@section('content')
<listado rol="commerce"></listado>
@endsection