@extends('layouts.app')

@section('content')
<codigos-de-barra></codigos-de-barra>
@endsection
