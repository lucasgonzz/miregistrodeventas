<template>
<div class="row justify-content-center">
	<div class="col-lg-7">	
		<div class="card">
			<div class="card-header">
				<div class="row justify-content-between align-items-center">
					<div class="col">
						<strong>Ventas de hoy 25 de diciembre</strong>
					</div>
					<div class="col">
						<button class="btn btn-success">
							Resumen
						</button>
						<button class="btn btn-primary">
							<i class="icon-calendar"></i>
							Desde una fecha
						</button>
					</div>
				</div>
			</div>
			<div class="card-body">
				<table class="table">
					<thead class="thead-dark">
						<tr>
							<th scope="col">Ver</th>
							<th scope="col">Hora</th>
							<th scope="col">Total</th>
							<th scope="col">Cant. Artículos</th>
						</tr>
					</thead>
					<tbody>
						<tr>
							<td class="td-options">
								<button class="btn btn-listado btn-listado-edit">
									<i class="icon-eye-1"></i>
								</button>
							</td>
							<td>
								<i class="icon-clock-1"></i>
								12:40
							</td>
							<th scope="row">$700</th>
							<td>4 artículos</td>
						</tr>
						<tr>
							<td class="td-options">
								<button class="btn btn-listado btn-listado-edit">
									<i class="icon-eye-1"></i>
								</button>
							</td>
							<td>
								<i class="icon-clock-1"></i>
								12:40
							</td>
							<th scope="row">$700</th>
							<td>4 artículos</td>
						</tr>
						<tr>
							<td class="td-options">
								<button class="btn btn-listado btn-listado-edit">
									<i class="icon-eye-1"></i>
								</button>
							</td>
							<td>
								<i class="icon-clock-1"></i>
								12:40
							</td>
							<th scope="row">$700</th>
							<td>4 artículos</td>
						</tr>
						<tr>
							<td class="td-options">
								<button class="btn btn-listado btn-listado-edit">
									<i class="icon-eye-1"></i>
								</button>
							</td>
							<td>
								<i class="icon-clock-1"></i>
								12:40
							</td>
							<th scope="row">$700</th>
							<td>4 artículos</td>
						</tr>
						<tr>
							<td class="td-options">
								<button class="btn btn-listado btn-listado-edit">
									<i class="icon-eye-1"></i>
								</button>
							</td>
							<td>
								<i class="icon-clock-1"></i>
								12:40
							</td>
							<th scope="row">$700</th>
							<td>4 artículos</td>
						</tr>
						<tr>
							<td class="td-options">
								<button class="btn btn-listado btn-listado-edit">
									<i class="icon-eye-1"></i>
								</button>
							</td>
							<td>
								<i class="icon-clock-1"></i>
								12:40
							</td>
							<th scope="row">$700</th>
							<td>4 artículos</td>
						</tr>
					</tbody>
				</table>
			</div>
			<div class="card-footer p-0">

			</div>
		</div>
	</div>
</div>
</template>
<script>
export default {
	data () {
		return {
			m: 'hola'
		}
	},
	methods: {
		showFromDate () {
			
		}
	}
}
</script>